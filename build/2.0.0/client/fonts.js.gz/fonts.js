var fonts = "";

export { fonts as default };
